<footer class="p-3 bg-gray-200 columns-2 ">
    <div class="">
        <img class="w-40" src="/images/logokecil.png" alt="Logo">
        <p class="text-sm pr-8">is a web-based application that sells various types of car brands. This application was created to make it easier for buyers so that buyers don't have to visit the place directly to see the car, just go through the website to see the details of the car and also with more flexible times.</p>
        <div class="flex py-10 items-center">
            <svg class="w-8 h-8 text-gray-800" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                <path d="M7.978 4a2.553 2.553 0 0 0-1.926.877C4.233 6.7 3.699 8.751 4.153 10.814c.44 1.995 1.778 3.893 3.456 5.572 1.68 1.679 3.577 3.018 5.57 3.459 2.062.456 4.115-.073 5.94-1.885a2.556 2.556 0 0 0 .001-3.861l-1.21-1.21a2.689 2.689 0 0 0-3.802 0l-.617.618a.806.806 0 0 1-1.14 0l-1.854-1.855a.807.807 0 0 1 0-1.14l.618-.62a2.692 2.692 0 0 0 0-3.803l-1.21-1.211A2.555 2.555 0 0 0 7.978 4Z"/>
              </svg>
              <span class="text-lg pl-2">097-8654-3296</span>          
        </div>
    </div>
    <div class="break-before-column pl-40 pt-4">
        <div class="flex items-center">
            <svg class="w-8 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" id="location"><path d="M12,2a8.009,8.009,0,0,0-8,8c0,3.255,2.363,5.958,4.866,8.819,0.792,0.906,1.612,1.843,2.342,2.791a1,1,0,0,0,1.584,0c0.73-.948,1.55-1.885,2.342-2.791C17.637,15.958,20,13.255,20,10A8.009,8.009,0,0,0,12,2Zm0,11a3,3,0,1,1,3-3A3,3,0,0,1,12,13Z"></path></svg>
            <span class="text-lg pl-2">Find our location</span>
        </div>
        <p class="text-sm pl-2 pt-4 pr-16">Jl. Ahmad Yani, Tlk. Tering, Kec. Batam Kota, Kota Batam, Kepulauan Riau 29461</p>
    </div>
</footer>