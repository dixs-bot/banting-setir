<link rel=”stylesheet” href=”https://cdn.tailwindcss.com/3.4.1”>
<link href="https://cdn.tailwindcss/css?family=figtree:400,600&display=swap" rel="stylesheet" />
<link rel=”stylesheet” href=”/style/tailwindcss3.4.1.js”>

